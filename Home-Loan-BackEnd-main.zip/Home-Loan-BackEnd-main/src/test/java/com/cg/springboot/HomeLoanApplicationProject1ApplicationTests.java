package com.cg.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeLoanApplicationProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
