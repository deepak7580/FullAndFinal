package com.cg.springboot.service;

import com.cg.springboot.entity.Admins;

public interface AdminService {

	void addNewUser(Admins admins);

}
